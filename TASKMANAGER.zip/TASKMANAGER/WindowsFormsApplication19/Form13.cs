﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 objUI = new Form11();
            objUI.ShowDialog();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "bassem")
            {
                MessageBox.Show("You don't can do it , he is your manager"); this.Hide();
                Form13 f = new Form13();
                f.ShowDialog();
            }
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            string del = @"delete from Admin where Name ='" + textBox1.Text.ToString() + "'";
            SqlCommand cmd2 = new SqlCommand();
            cmd2.CommandText = del;
            cmd2.Connection = con;
            cmd2.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("the person is deleted");
            this.Hide();
            Form11 objUI = new Form11();
            objUI.ShowDialog();
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 objUI = new Form9();
            objUI.ShowDialog();
        }
    }
}
