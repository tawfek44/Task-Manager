﻿namespace WindowsFormsApplication19
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.flatMini1 = new theme.FlatMini();
            this.flatClose1 = new theme.FlatClose();
            this.flatButton2 = new theme.FlatButton();
            this.flatButton3 = new theme.FlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.flatLabel1 = new theme.FlatLabel();
            this.flatLabel4 = new theme.FlatLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flatLabel3 = new theme.FlatLabel();
            this.flatLabel8 = new theme.FlatLabel();
            this.flatButton7 = new theme.FlatButton();
            this.flatButton8 = new theme.FlatButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.flatLabel5 = new theme.FlatLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.flatButton12 = new theme.FlatButton();
            this.flatLabel2 = new theme.FlatLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.flatLabel6 = new theme.FlatLabel();
            this.flatLabel7 = new theme.FlatLabel();
            this.flatLabel9 = new theme.FlatLabel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.flatLabel10 = new theme.FlatLabel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.flatLabel11 = new theme.FlatLabel();
            this.flatLabel12 = new theme.FlatLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // flatMini1
            // 
            this.flatMini1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flatMini1.BackColor = System.Drawing.Color.White;
            this.flatMini1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.flatMini1.Font = new System.Drawing.Font("Marlett", 12F);
            this.flatMini1.Location = new System.Drawing.Point(637, 3);
            this.flatMini1.Name = "flatMini1";
            this.flatMini1.Size = new System.Drawing.Size(18, 18);
            this.flatMini1.TabIndex = 7;
            this.flatMini1.Text = "flatMini1";
            this.flatMini1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // flatClose1
            // 
            this.flatClose1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flatClose1.BackColor = System.Drawing.Color.White;
            this.flatClose1.BaseColor = System.Drawing.Color.Maroon;
            this.flatClose1.Font = new System.Drawing.Font("Marlett", 10F);
            this.flatClose1.Location = new System.Drawing.Point(665, 3);
            this.flatClose1.Name = "flatClose1";
            this.flatClose1.Size = new System.Drawing.Size(18, 18);
            this.flatClose1.TabIndex = 8;
            this.flatClose1.Text = "flatClose1";
            this.flatClose1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // flatButton2
            // 
            this.flatButton2.BackColor = System.Drawing.Color.Transparent;
            this.flatButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.flatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton2.Enabled = false;
            this.flatButton2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.flatButton2.Location = new System.Drawing.Point(49, 49);
            this.flatButton2.Name = "flatButton2";
            this.flatButton2.Rounded = false;
            this.flatButton2.Size = new System.Drawing.Size(231, 43);
            this.flatButton2.TabIndex = 11;
            this.flatButton2.Text = "Update";
            this.flatButton2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // flatButton3
            // 
            this.flatButton3.BackColor = System.Drawing.Color.Transparent;
            this.flatButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.flatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton3.Enabled = false;
            this.flatButton3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.flatButton3.Location = new System.Drawing.Point(403, 49);
            this.flatButton3.Name = "flatButton3";
            this.flatButton3.Rounded = false;
            this.flatButton3.Size = new System.Drawing.Size(232, 43);
            this.flatButton3.TabIndex = 12;
            this.flatButton3.Text = "Search";
            this.flatButton3.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::WindowsFormsApplication19.Properties.Resources.IMG_20181201_1014311;
            this.pictureBox1.Location = new System.Drawing.Point(13, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 21);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel1.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel1.Location = new System.Drawing.Point(67, 139);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(121, 21);
            this.flatLabel1.TabIndex = 27;
            this.flatLabel1.Text = "Add Employee";
            this.flatLabel1.Click += new System.EventHandler(this.flatLabel1_Click);
            // 
            // flatLabel4
            // 
            this.flatLabel4.AutoSize = true;
            this.flatLabel4.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel4.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel4.Location = new System.Drawing.Point(67, 177);
            this.flatLabel4.Name = "flatLabel4";
            this.flatLabel4.Size = new System.Drawing.Size(144, 21);
            this.flatLabel4.TabIndex = 30;
            this.flatLabel4.Text = "Delete  Employee";
            this.flatLabel4.Click += new System.EventHandler(this.flatLabel4_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.flatLabel3);
            this.panel1.Controls.Add(this.flatClose1);
            this.panel1.Controls.Add(this.flatMini1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(693, 24);
            this.panel1.TabIndex = 39;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // flatLabel3
            // 
            this.flatLabel3.AutoSize = true;
            this.flatLabel3.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel3.ForeColor = System.Drawing.Color.White;
            this.flatLabel3.Location = new System.Drawing.Point(297, 1);
            this.flatLabel3.Name = "flatLabel3";
            this.flatLabel3.Size = new System.Drawing.Size(56, 21);
            this.flatLabel3.TabIndex = 27;
            this.flatLabel3.Text = "Admin";
            // 
            // flatLabel8
            // 
            this.flatLabel8.AutoSize = true;
            this.flatLabel8.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel8.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel8.Location = new System.Drawing.Point(410, 138);
            this.flatLabel8.Name = "flatLabel8";
            this.flatLabel8.Size = new System.Drawing.Size(193, 21);
            this.flatLabel8.TabIndex = 49;
            this.flatLabel8.Text = "List of Employees Name";
            this.flatLabel8.Click += new System.EventHandler(this.flatLabel8_Click);
            // 
            // flatButton7
            // 
            this.flatButton7.BackColor = System.Drawing.Color.Transparent;
            this.flatButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.flatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton7.Enabled = false;
            this.flatButton7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatButton7.Location = new System.Drawing.Point(414, 172);
            this.flatButton7.Name = "flatButton7";
            this.flatButton7.Rounded = false;
            this.flatButton7.Size = new System.Drawing.Size(126, 32);
            this.flatButton7.TabIndex = 48;
            this.flatButton7.Text = "Enter Employee Name";
            this.flatButton7.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // flatButton8
            // 
            this.flatButton8.BackColor = System.Drawing.Color.Transparent;
            this.flatButton8.BaseColor = System.Drawing.Color.Maroon;
            this.flatButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton8.Enabled = false;
            this.flatButton8.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.flatButton8.Location = new System.Drawing.Point(407, 98);
            this.flatButton8.Name = "flatButton8";
            this.flatButton8.Rounded = false;
            this.flatButton8.Size = new System.Drawing.Size(196, 32);
            this.flatButton8.TabIndex = 47;
            this.flatButton8.Text = "search about Employee";
            this.flatButton8.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(546, 179);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(118, 17);
            this.textBox2.TabIndex = 46;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Maroon;
            this.panel2.Location = new System.Drawing.Point(71, 198);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(74, 1);
            this.panel2.TabIndex = 54;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.flatLabel5);
            this.panel3.Location = new System.Drawing.Point(71, 159);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(74, 1);
            this.panel3.TabIndex = 55;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Maroon;
            this.panel5.Location = new System.Drawing.Point(-19, 10);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(74, 1);
            this.panel5.TabIndex = 57;
            // 
            // flatLabel5
            // 
            this.flatLabel5.AutoSize = true;
            this.flatLabel5.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel5.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel5.Location = new System.Drawing.Point(-23, -10);
            this.flatLabel5.Name = "flatLabel5";
            this.flatLabel5.Size = new System.Drawing.Size(121, 21);
            this.flatLabel5.TabIndex = 56;
            this.flatLabel5.Text = "Add Employee";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Maroon;
            this.panel6.Location = new System.Drawing.Point(410, 157);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(188, 1);
            this.panel6.TabIndex = 56;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 50;
            this.bunifuElipse1.TargetControl = this;
            // 
            // flatButton12
            // 
            this.flatButton12.BackColor = System.Drawing.Color.Transparent;
            this.flatButton12.BaseColor = System.Drawing.Color.Black;
            this.flatButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatButton12.Location = new System.Drawing.Point(472, 226);
            this.flatButton12.Name = "flatButton12";
            this.flatButton12.Rounded = false;
            this.flatButton12.Size = new System.Drawing.Size(126, 32);
            this.flatButton12.TabIndex = 60;
            this.flatButton12.Text = "Submit";
            this.flatButton12.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.flatButton12.Click += new System.EventHandler(this.flatButton12_Click);
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel2.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel2.Location = new System.Drawing.Point(67, 213);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(99, 21);
            this.flatLabel2.TabIndex = 28;
            this.flatLabel2.Text = "Add Project";
            this.flatLabel2.Click += new System.EventHandler(this.flatLabel2_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Maroon;
            this.panel4.Location = new System.Drawing.Point(84, 237);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(63, 1);
            this.panel4.TabIndex = 55;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Maroon;
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.flatLabel6);
            this.panel7.Location = new System.Drawing.Point(71, 129);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(74, 1);
            this.panel7.TabIndex = 62;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Maroon;
            this.panel8.Location = new System.Drawing.Point(-19, 10);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(74, 1);
            this.panel8.TabIndex = 57;
            // 
            // flatLabel6
            // 
            this.flatLabel6.AutoSize = true;
            this.flatLabel6.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel6.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel6.Location = new System.Drawing.Point(-23, -10);
            this.flatLabel6.Name = "flatLabel6";
            this.flatLabel6.Size = new System.Drawing.Size(121, 21);
            this.flatLabel6.TabIndex = 56;
            this.flatLabel6.Text = "Add Employee";
            // 
            // flatLabel7
            // 
            this.flatLabel7.AutoSize = true;
            this.flatLabel7.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel7.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel7.Location = new System.Drawing.Point(67, 109);
            this.flatLabel7.Name = "flatLabel7";
            this.flatLabel7.Size = new System.Drawing.Size(103, 21);
            this.flatLabel7.TabIndex = 61;
            this.flatLabel7.Text = "View Profile";
            this.flatLabel7.Click += new System.EventHandler(this.flatLabel7_Click);
            // 
            // flatLabel9
            // 
            this.flatLabel9.AutoSize = true;
            this.flatLabel9.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel9.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel9.Location = new System.Drawing.Point(70, 256);
            this.flatLabel9.Name = "flatLabel9";
            this.flatLabel9.Size = new System.Drawing.Size(133, 21);
            this.flatLabel9.TabIndex = 63;
            this.flatLabel9.Text = "Calculate Salary";
            this.flatLabel9.Click += new System.EventHandler(this.flatLabel9_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Maroon;
            this.panel9.Location = new System.Drawing.Point(84, 280);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(63, 1);
            this.panel9.TabIndex = 56;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 333);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(675, 79);
            this.dataGridView1.TabIndex = 64;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Silver;
            this.panel10.Controls.Add(this.flatLabel10);
            this.panel10.Location = new System.Drawing.Point(219, 308);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(200, 24);
            this.panel10.TabIndex = 65;
            // 
            // flatLabel10
            // 
            this.flatLabel10.AutoSize = true;
            this.flatLabel10.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel10.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel10.Location = new System.Drawing.Point(36, 2);
            this.flatLabel10.Name = "flatLabel10";
            this.flatLabel10.Size = new System.Drawing.Size(134, 21);
            this.flatLabel10.TabIndex = 66;
            this.flatLabel10.Text = "Result Of Search";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Maroon;
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Controls.Add(this.flatLabel11);
            this.panel11.Location = new System.Drawing.Point(84, 308);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(74, 1);
            this.panel11.TabIndex = 64;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Maroon;
            this.panel12.Location = new System.Drawing.Point(-19, 10);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(74, 1);
            this.panel12.TabIndex = 57;
            // 
            // flatLabel11
            // 
            this.flatLabel11.AutoSize = true;
            this.flatLabel11.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel11.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel11.Location = new System.Drawing.Point(-23, -10);
            this.flatLabel11.Name = "flatLabel11";
            this.flatLabel11.Size = new System.Drawing.Size(121, 21);
            this.flatLabel11.TabIndex = 56;
            this.flatLabel11.Text = "Add Employee";
            // 
            // flatLabel12
            // 
            this.flatLabel12.AutoSize = true;
            this.flatLabel12.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flatLabel12.ForeColor = System.Drawing.Color.Maroon;
            this.flatLabel12.Location = new System.Drawing.Point(76, 289);
            this.flatLabel12.Name = "flatLabel12";
            this.flatLabel12.Size = new System.Drawing.Size(106, 21);
            this.flatLabel12.TabIndex = 63;
            this.flatLabel12.Text = "View Project";
            this.flatLabel12.Click += new System.EventHandler(this.flatLabel12_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Purple;
            this.BackgroundImage = global::WindowsFormsApplication19.Properties.Resources._18359179_293501107764800_6072180567856025607_o;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(702, 444);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.flatLabel12);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.flatLabel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.flatLabel7);
            this.Controls.Add(this.flatButton12);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.flatLabel8);
            this.Controls.Add(this.flatButton7);
            this.Controls.Add(this.flatButton8);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.flatLabel4);
            this.Controls.Add(this.flatLabel2);
            this.Controls.Add(this.flatLabel1);
            this.Controls.Add(this.flatButton3);
            this.Controls.Add(this.flatButton2);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private theme.FlatMini flatMini1;
        private theme.FlatClose flatClose1;
        private theme.FlatButton flatButton2;
        private theme.FlatButton flatButton3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private theme.FlatLabel flatLabel1;
        private theme.FlatLabel flatLabel4;
        private System.Windows.Forms.Panel panel1;
        private theme.FlatLabel flatLabel3;
        private theme.FlatLabel flatLabel8;
        private theme.FlatButton flatButton7;
        private theme.FlatButton flatButton8;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private theme.FlatButton flatButton12;
        private System.Windows.Forms.Panel panel4;
        private theme.FlatLabel flatLabel2;
        private System.Windows.Forms.Panel panel5;
        private theme.FlatLabel flatLabel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private theme.FlatLabel flatLabel6;
        private theme.FlatLabel flatLabel7;
        private System.Windows.Forms.Panel panel9;
        private theme.FlatLabel flatLabel9;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel10;
        private theme.FlatLabel flatLabel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private theme.FlatLabel flatLabel11;
        private theme.FlatLabel flatLabel12;
    }
}