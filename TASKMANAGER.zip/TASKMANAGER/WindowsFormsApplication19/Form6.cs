﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication19
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void flatTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatClose1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 objUI = new Form7();
            objUI.ShowDialog();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void flatTextBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatTextBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatLabel12_Click(object sender, EventArgs e)
        {

        }

        private void flatTextBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatTextBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatTextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatLabel8_Click(object sender, EventArgs e)
        {

        }

        private void flatTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatLabel6_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel4_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel3_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel14_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel13_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel30_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel29_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel28_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel27_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel26_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel25_Click(object sender, EventArgs e)
        {

        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            string insertstring = @"insert into Task (Title, StartDate, DeadLine, [Description], ProjectId, EmpId) values (@title, @startdate, @enddate, @description, " + "(select Id from Project where Title = '" + textBox10.Text + "')" + "," + "(select Id from Employee where [Name] = '" + textBox4.Text + "')" + " )";
            // string insertstring2 = @"insert into Task (ProjectId, EmpId) values ( " + "(select Id from Project where Title = '" + textBox26.Text + "')" + "," + "(select Id from Employee where [Name] = '" + textBox1.Text + "')" + " )";

            SqlCommand cmd = new SqlCommand(insertstring, con);
            // SqlCommand cmd2 = new SqlCommand(insertstring2, con);

            SqlParameter title = new SqlParameter("@title", textBox2.Text);
            cmd.Parameters.Add(title);
            SqlParameter startdate = new SqlParameter("@startdate", textBox6.Text);
            cmd.Parameters.Add(startdate);
            SqlParameter enddate = new SqlParameter("@enddate", textBox9.Text);
            cmd.Parameters.Add(enddate);
            SqlParameter description = new SqlParameter("@description", textBox3.Text);
            cmd.Parameters.Add(description);

            cmd.ExecuteNonQuery();
            //cmd2.ExecuteNonQuery();

            string insertstring2 = @"insert into Task (Title, StartDate, DeadLine, [Description], ProjectId, EmpId) values (@title, @startdate, @enddate, @description, " + "(select Id from Project where Title = '" + textBox10.Text + "')" + "," + "(select Id from Employee where [Name] = '" + textBox14.Text + "')" + " )";
            // string insertstring2 = @"insert into Task (ProjectId, EmpId) values ( " + "(select Id from Project where Title = '" + textBox26.Text + "')" + "," + "(select Id from Employee where [Name] = '" + textBox1.Text + "')" + " )";

            SqlCommand cmd2 = new SqlCommand(insertstring2, con);
            // SqlCommand cmd2 = new SqlCommand(insertstring2, con);

            SqlParameter title2 = new SqlParameter("@title", textBox8.Text);
            cmd2.Parameters.Add(title2);
            SqlParameter startdate2 = new SqlParameter("@startdate", textBox13.Text);
            cmd2.Parameters.Add(startdate2);
            SqlParameter enddate2 = new SqlParameter("@enddate", textBox12.Text);
            cmd2.Parameters.Add(enddate2);
            SqlParameter description2 = new SqlParameter("@description", textBox7.Text);
            cmd2.Parameters.Add(description2);

            cmd2.ExecuteNonQuery();


            MessageBox.Show("the Project is added");
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
            con.Close();
        }

        private void flatLabel3_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
