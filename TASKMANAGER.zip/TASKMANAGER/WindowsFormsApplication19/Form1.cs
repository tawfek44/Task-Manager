﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form1 : Form
    {
        bool manager = false, admin = false, employee = false;

        public Form1()
        {
            InitializeComponent();
          
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        int c = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            c++; 
            if(c==1)textBox1.Text = string.Empty;
        }
       int c1=0;
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            c1++; 
            if(c1==1)textBox2.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
      
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            SqlDataAdapter manger = new SqlDataAdapter("select count(*) from [Admin] where [Name]='" + textBox1.Text + "'and [Password]='" + textBox2.Text + "'and IsManager = 1 ", con);
            SqlDataAdapter admn = new SqlDataAdapter("select count(*) from [Admin] where [Name]='" + textBox1.Text + "'and [Password]='" + textBox2.Text + "'and IsManager = 0 ", con);
            SqlDataAdapter emp = new SqlDataAdapter("select count(*) from Employee where [Name]='" + textBox1.Text + "'and [Password]='" + textBox2.Text + "'", con);
            DataTable  ad= new DataTable();
            DataTable mg = new DataTable();
            DataTable ep = new DataTable();
            admn.Fill(ad);
            emp.Fill(ep);
            manger.Fill(mg);

            if (textBox1.Text == "UserName" || textBox1.Text == string.Empty || textBox2.Text == "Password" || textBox2.Text == string.Empty)
                label8.Text = "InValid E-mail Or Password !!";
            if (manager == true && admin == false && employee == false )
            {
                if (mg.Rows[0][0].ToString() == "1")
                {
                    this.Hide();
                    Form11 objUI = new Form11();
                    objUI.ShowDialog();
                }
                else
                {
                    label8.Text = "Invalid E-mail or Password !!";
                }

            }
            else if (manager == false && admin == true && employee == false)
            {
                if (ad.Rows[0][0].ToString() == "1")
                {
                    this.Hide();
                    Form3 objUI = new Form3();
                    objUI.ShowDialog();
                }
                else
                {
                    label8.Text = "Invalid E-mail or Password !!";
                }
            }
            else if(manager==false && admin==false || employee==true){
                if (ep.Rows[0][0].ToString() == "1")
                {
                    this.Hide();
                    Form2 objUI = new Form2();
                    objUI.ShowDialog();
                }
                else
                {
                    label8.Text = "Invalid E-mail or Password !!";
                }
            }
            if(!manager&&!admin&&!employee)
            {
                label7.Text = "Invalid !!";
            }
            
        }
        int c2 = 0;
        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            c2++;
            if (c2 % 2 != 0) textBox2.UseSystemPasswordChar = true;
            else textBox2.UseSystemPasswordChar = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 objUI = new Form8();
            objUI.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            label7.Text = "";
            manager = true;
            admin = false;
            employee = false;
            label3.ForeColor = Color.Gold;
            panel4.BackColor = Color.Gold;
            label4.ForeColor = Color.White;
            panel5.BackColor = Color.White;
            label5.ForeColor = Color.White;
            panel6.BackColor = Color.White;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label7.Text = "";
            admin = true;
            manager = false;
            employee = false;
            label3.ForeColor = Color.White;
            panel4.BackColor = Color.White;
            label4.ForeColor = Color.Gold;
            panel5.BackColor = Color.Gold;
            label5.ForeColor = Color.White;
            panel6.BackColor = Color.White;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            label7.Text = "";
            employee = true;
            manager = false;
            admin = false;
            label3.ForeColor = Color.White;
            panel4.BackColor = Color.White;
            label4.ForeColor = Color.White;
            panel5.BackColor = Color.White;
            label5.ForeColor = Color.Gold;
            panel6.BackColor = Color.Gold;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            label8.Text = "";
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            label8.Text = "";
        }
     
    }
}
