﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form15 : Form
    {
   
        public Form15()
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name from Employee", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Name");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Name"] = rdr["Name"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        
            this.Hide();
            Form2 objUI = new Form2();
            objUI.ShowDialog();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Changes Saved");
            this.Hide();
            Form2 objUI = new Form2();
            objUI.ShowDialog();
        }

        private void Form15_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 objUI = new Form1();
            objUI.ShowDialog();
        }
    }
}
