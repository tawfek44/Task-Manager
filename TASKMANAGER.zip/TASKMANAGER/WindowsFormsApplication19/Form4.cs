﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{

    public partial class Form4 : Form
    {
       // string connectionString = @"Data Source=.\sqlexpress;Initial Catalog=taskmanager1;Integrated Security=True;";

        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
      int c = 0;  
        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
             c++;
          if(c%2!=0)  textBox2.UseSystemPasswordChar = true;
          else textBox2.UseSystemPasswordChar = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
     
       
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
           
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            string insert = @"insert into Employee(Name,Password,SalrayPerHour,WorkPerMonth)values(@Name,@Password,@SalrayPerHour,@WorkPerMonth)";
            SqlCommand cmd = new SqlCommand(insert, con);
            SqlParameter parameterName = new SqlParameter("@Name", textBox1.Text.ToString());
            cmd.Parameters.Add(parameterName);
            SqlParameter parameterPassword = new SqlParameter("@Password", textBox2.Text.ToString());
            cmd.Parameters.Add(parameterPassword);
            SqlParameter parametersalaryperhours = new SqlParameter("@SalrayPerHour", float.Parse(textBox3.Text));
            cmd.Parameters.Add(parametersalaryperhours);
            SqlParameter parameterworkpermonth = new SqlParameter("@WorkPerMonth", float.Parse(textBox4.Text));
            cmd.Parameters.Add(parameterworkpermonth);
            cmd.ExecuteNonQuery();
            con.Close();
           MessageBox.Show("the Employee is added");
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog(); 
        }
        }
    }

