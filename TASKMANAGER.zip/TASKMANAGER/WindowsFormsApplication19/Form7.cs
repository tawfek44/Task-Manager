﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication19
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void flatLabel5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 objUI = new Form6();
            objUI.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            string insertstring = @"insert into Project (Title, StartDate, DeadLine, [Description]) values (@title, @startdate, @enddate, @description)";
            SqlCommand cmd = new SqlCommand(insertstring, con);
            SqlParameter title = new SqlParameter("@title", textBox1.Text);
            cmd.Parameters.Add(title);
            SqlParameter startdate = new SqlParameter("@startdate", textBox4.Text);
            cmd.Parameters.Add(startdate);
            SqlParameter enddate = new SqlParameter("@enddate", textBox3.Text);
            cmd.Parameters.Add(enddate);
            SqlParameter description = new SqlParameter("@description", textBox2.Text);
            cmd.Parameters.Add(description);

            cmd.ExecuteNonQuery();

            this.Hide();
            Form6 objUI = new Form6();
            objUI.ShowDialog();
            con.Close();
        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
