﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
           
        }

        private void Form16_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Task.Id,Task.Title,Task.Description,Task.ProjectId from Task inner join Employee  on Task.EmpId =Employee.Id where Task.EmpId= Employee.Id and Employee.[Name]='" + flatTextBox1.Text.ToString() + "' and Employee.[Password]='" + flatTextBox2.Text.ToString() + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Id");
            tbl.Columns.Add("Title");
            tbl.Columns.Add("Description");
            tbl.Columns.Add("ProjectId");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Id"] = rdr["Id"];
                row["Title"] = rdr["Title"];
                row["Description"] = rdr["Description"];
                row["ProjectId"] = rdr["ProjectId"];
                tbl.Rows.Add(row);
            }
           rdr.Close(); 
            dataGridView1.DataSource = tbl;
           con.Close();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 objUI = new Form2();
            objUI.ShowDialog();
        }
    }
}
