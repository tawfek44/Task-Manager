﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication19
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                  Form4 objUI = new Form4();
            objUI.ShowDialog();
            this.Close();
        }
        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void flatClose1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender)
        {

        }

        private void flatButton2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 objUI = new Form1();
            objUI.ShowDialog();
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 objUI = new Form10();
            objUI.ShowDialog();
        }

        private void flatLabel5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form15 objUI = new Form15();
            objUI.ShowDialog();

        }

        private void flatLabel3_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form14 objUI = new Form14();
            objUI.ShowDialog();
        }

        private void flatLabel4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form16 objUI = new Form16();
            objUI.ShowDialog();
        }

        private void flatLabel5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form19 objUI = new Form19();
            objUI.ShowDialog();
        }
    }
}
