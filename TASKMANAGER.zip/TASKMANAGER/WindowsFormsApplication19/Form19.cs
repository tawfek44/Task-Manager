﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Id,Title,StartDate,DeadLine,Description from Project where Id='" + flatTextBox1.Text.ToString() + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Id");
            tbl.Columns.Add("Title");
            tbl.Columns.Add("StartDate");
            tbl.Columns.Add("DeadLine");
            tbl.Columns.Add("Description");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Id"] = rdr["Id"];
                row["Title"] = rdr["Title"];
                row["StartDate"] = rdr["StartDate"];
                row["DeadLine"] = rdr["DeadLine"];
                row["Description"] = rdr["Description"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 objUI = new Form1();
            objUI.ShowDialog();
        }
    }
}
