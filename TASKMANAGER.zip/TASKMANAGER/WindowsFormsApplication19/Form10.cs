﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication19
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
           
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 objUI = new Form2();
            objUI.ShowDialog();
        }

        private void flatButton6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();


         if (textBox4.Text != "")
            {
                radioButton2.Checked = true;
                string updateString1 = @"update Task set EmpId = '" + textBox4.Text + "' where Id = '" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(updateString1);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
            }
           if (textBox3.Text != "")
            {
                string updateString2 = @"update Task set Comment = '" + textBox3.Text + "' where Id = '" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(updateString2);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
            }
           if (radioButton1.Checked == true)
           {
               string updateString = @"update Task set [Status] = 1 where Id = '" + textBox2.Text + "'";
               SqlCommand cmd = new SqlCommand(updateString);
               cmd.Connection = con;
               cmd.ExecuteNonQuery();
           }

           else if (radioButton2.Checked == true)
           {
               string updateString = @"update Task set [Status] = 0 where Id = '" + textBox2.Text + "'";
               SqlCommand cmd = new SqlCommand(updateString);
               cmd.Connection = con;
               cmd.ExecuteNonQuery();

           }
           MessageBox.Show("Changes Saved");
            this.Hide();
            Form2 objUI = new Form2();
            objUI.ShowDialog();
            con.Close();
        }

        private void flatButton5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name ,Id  from Employee", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Id");
            tbl.Columns.Add("Name");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Id"] = rdr["Id"];
                row["Name"] = rdr["Name"];

                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView2.DataSource = tbl;


        }

        private void Form10_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void flatButton7_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Task.Id,Task.Title,Task.ProjectId  from Task inner join Employee  on Task.EmpId =Employee.Id where Task.EmpId= Employee.Id and Employee.[Name]='" + textBox1.Text.ToString() + "' and Employee.[Password]='" + textBox5.Text.ToString() + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Id");
            tbl.Columns.Add("Title");
            tbl.Columns.Add("ProjectId");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Id"] = rdr["Id"];
                row["Title"] = rdr["Title"];
                row["ProjectId"] = rdr["ProjectId"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
        }
    }
}
