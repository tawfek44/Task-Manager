﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("the Employee is deleted");
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
    
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            string del = @"delete from Employee where Name ='" + textBox1.Text.ToString() + "'";
            SqlCommand cmd2 = new SqlCommand();
            cmd2.CommandText = del;
            cmd2.Connection = con;
            cmd2.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("the person is deleted");
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form15 objUI = new Form15();
            objUI.ShowDialog();
        }
    }
}
