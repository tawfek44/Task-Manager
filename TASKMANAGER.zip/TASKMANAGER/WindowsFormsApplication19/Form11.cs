﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication19
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void flatLabel4_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            Form12 objUI = new Form12();
            objUI.ShowDialog();
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form13 objUI = new Form13();
            objUI.ShowDialog();
        }

        private void flatLabel3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form14 objUI = new Form14();
            objUI.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 objUI = new Form1();
            objUI.ShowDialog();
        }

        private void flatLabel3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form18 objUI = new Form18();
            objUI.ShowDialog();
        }
    }
}
