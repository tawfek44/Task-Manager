﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{

    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender)
        {
            this.Hide();   
            Form5 objUI = new Form5();
            objUI.ShowDialog();
         
        }

        private void flatButton4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender)
        {
            this.Hide();
            Form4 objUI = new Form4();
            objUI.ShowDialog();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 objUI = new Form1();
            objUI.ShowDialog();
        }

        private void radioButton3_CheckedChanged(object sender)
        {
            this.Hide();
            Form6 objUI = new Form6();
            objUI.ShowDialog();
        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 objUI = new Form4();
            objUI.ShowDialog();
        }

        private void flatLabel4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 objUI = new Form5();
            objUI.ShowDialog();
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            Form7 objUI = new Form7();
            objUI.ShowDialog();
       
        }

        private void flatLabel5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 objUI = new Form9();
            objUI.ShowDialog();
        }

        private void flatLabel10_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel11_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel12_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flatLabel8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form15 objUI = new Form15();
            objUI.ShowDialog();
        }

        private void flatLabel7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 objUI = new Form8();
            objUI.ShowDialog();
        }

        private void flatLabel9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form17 objUI = new Form17();
            objUI.ShowDialog();
        }

        private void flatButton12_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Employee.[Name],Task.EmpId,Task.ProjectId ,Task.Title,Task.Id from Task inner join Employee  on Task.EmpId =Employee.Id where Task.EmpId= Employee.Id and Employee.[Name]='" + textBox2.Text.ToString() + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Employee Name");
             tbl.Columns.Add("Employee Id");
            tbl.Columns.Add("Project Id");
            tbl.Columns.Add("Task Title"); 
            tbl.Columns.Add("Task Id"); 
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Employee.[Name]"] = rdr["Employee.[Name]"];
               row["Task.EmpId"] = rdr["Task.EmpId"]; 
               row["ProjectId"] = rdr["ProjectId"];   
               row["Task.Title"] = rdr["Task.Title"];
               row["Task.Id"] = rdr["Task.Id"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
        }

        private void flatLabel12_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form19 objUI = new Form19();
            objUI.ShowDialog();
        }
    }
}
