﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name from Admin", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Name");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Name"] = rdr["Name"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            if (flatTextBox2.Text != "")
            {
                string updateString1 = @"update Admin set WorkPerMonth = '" + flatTextBox2.Text + "' where Name = '" + flatTextBox1.Text + "'";
                SqlCommand cmd2 = new SqlCommand(updateString1);
                cmd2.Connection = con;
                cmd2.ExecuteNonQuery();
                ////////////////////////////////////////////////////
                textBox1.Enabled = true;
                SqlCommand cmd = new SqlCommand("select SalrayPerHour from Admin where Name='" + flatTextBox1.Text.ToString() + "'", con);
                cmd.Connection = con;
                int salary = (int)cmd.ExecuteScalar();
                SqlCommand cmd1 = new SqlCommand("select WorkPerMonth from Admin where Name ='" + flatTextBox1.Text.ToString() + "'", con);
                cmd1.Connection = con;
                int workmonth = (int)cmd1.ExecuteScalar();
                int calculate = salary * workmonth;
                textBox1.Text = calculate.ToString();
                textBox1.Enabled = false;
                con.Close();
            }
            else MessageBox.Show(" Invalid Name Of Admin Or Work/Month ");
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form11 objUI = new Form11();
            objUI.ShowDialog();
        }
    }
}
