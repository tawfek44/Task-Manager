﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication19
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 objUI = new Form11();
            objUI.ShowDialog();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" changes are saved");
            this.Hide();
            Form11 objUI = new Form11();
            objUI.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form14_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form2 objUI = new Form2();
            objUI.ShowDialog();
        }

        private void flatButton1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name,Password,SalrayPerHour from Employee where Name='" + flatTextBox1.Text.ToString() + "' and Password='" + flatTextBox2.Text.ToString() + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Name");
            tbl.Columns.Add("Password");
            tbl.Columns.Add("SalrayPerHour");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Name"] = rdr["Name"];
                row["Password"] = rdr["Password"];
                row["SalrayPerHour"] = rdr["SalrayPerHour"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;

        }
    }
}
