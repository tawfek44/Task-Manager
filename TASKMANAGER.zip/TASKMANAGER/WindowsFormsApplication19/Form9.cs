﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication19
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Title ,Id  from Task", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
        tbl.Columns.Add("Id");  
        tbl.Columns.Add("Title");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
              row["Id"] = rdr["Id"]; 
                row["Title"] = rdr["Title"];
               
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
            
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("changes are saved");
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 objUI = new Form3();
            objUI.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=taskmanager;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name from Admin",con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Columns.Add("Name");
            DataRow row;
            while (rdr.Read())
            {
                row = tbl.NewRow();
                row["Name"] = rdr["Name"];
                tbl.Rows.Add(row);
            }
            rdr.Close();
            con.Close();
            dataGridView1.DataSource = tbl;
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form13 objUI = new Form13();
            objUI.ShowDialog();
        }
    }
}
